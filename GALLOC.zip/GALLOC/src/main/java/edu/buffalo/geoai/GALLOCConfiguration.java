package edu.buffalo.geoai;

public class GALLOCConfiguration {
	
	public static String database_name = "galloc_db.db";
	
	public static String user_role_creator = "creator";
	
	public static String user_role_administrator = "administrator";
	
	public static String user_role_annotator = "annotator";

}
